package nba.project.entity;

public enum Position {
    GUARD,
    FORWARD,
    CENTER
}
